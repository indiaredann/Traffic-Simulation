import threading
from unittest import signals

import pygame
import sys
import time
import random
from matplotlib import pyplot as plt
from pygame.examples.go_over_there import screen

# Define colors
TAN = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Define window dimensions
WIDTH, HEIGHT = 800, 800
# define car dimensions
car_width, car_height = 40, 20
# Define traffic light dimensions
LIGHT_WIDTH, LIGHT_HEIGHT = 30, 90
MARGIN = 20

# Initialize Pygame
pygame.init()

# Create window
window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Traffic Light Simulation--Car Intersection")


# Function to draw the traffic light
def draw_traffic_light(light1, light2):
    def draw_traffic_light(light1, light2):
        pygame.draw.rect(window, TAN, (WIDTH // 2 - LIGHT_WIDTH // 2, MARGIN, LIGHT_WIDTH, LIGHT_HEIGHT))
        pygame.draw.circle(window, light1, (WIDTH // 2, MARGIN + LIGHT_HEIGHT // 4), 15)

        pygame.draw.rect(window, TAN,
                         (WIDTH // 2 - LIGHT_WIDTH // 2, HEIGHT - MARGIN - LIGHT_HEIGHT, LIGHT_WIDTH, LIGHT_HEIGHT))
        pygame.draw.circle(window, light2, (WIDTH // 2, HEIGHT - MARGIN - 3 * LIGHT_HEIGHT // 4), 15)


# draw car function
def car(x, y, vehicle_type):
    color = WHITE
    if vehicle_type == "bus":
        color = (0, 0, 255)  # blue for buses
    elif vehicle_type == "truck":
        color = (255, 255, 0)  # Yellow for trucks
    pygame.draw.rect(window, color, (x, y, car_width, car_height))


def simulate_traffic_light(lightDuration, car_probabilities, simulation_duration,
                           busProb=None, truckProb=None, leftTurn=None):
    # intialize traffic light colors
    light1 = GREEN
    light2 = RED

    # inital car position

    totalCars = 0

    # car speed
    # car_speed = 5

    cars_passed = 3
    total_wait_time = 0

    clock = pygame.time.Clock()

    vehicle_types = ['car', 'bus', 'truck']
    vehicleProb = {'car': car_probabilities, 'bus': busProb, 'truck': truckProb}
    vehicleTime = {'car': 3, 'bus': 5, 'truck': 7}

    current_time = 0
    while current_time < simulation_duration:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # update traffic light colors
        draw_traffic_light(light1, light2)
        # Simulate cars arriving at the intersection
        for vehicle_type in vehicle_types:
            if random.random() <= vehicleProb[vehicle_type]:
                # Check if the car can proceed (no left turn)
                if random.random() > leftTurn:
                    totalCars += 1
                    total_wait_time += vehicleTime[vehicle_type]

                    car(WIDTH // 2 - car_width // 2, HEIGHT - MARGIN - car_height, vehicle_type)

        print(f"Time:{time}s State:{light1} Total Cars Passed: {cars_passed} Total Wait Time: {total_wait_time:.2f}s")
        pygame.display.flip()
        clock.tick(1)

        # change traffic light colors
        if light1 == GREEN:
            light1 = RED
            light2 = GREEN

        else:
            light1 = GREEN
            light2 = RED

        window.fill(TAN)

        # Print statistics
        print(f"Total Cars Passed: {cars_passed} Total Wait Time: {total_wait_time:.2f}s")

        # Calculate average wait time and cars per second passed
        avg_wait_time = total_wait_time / cars_passed if cars_passed > 0 else 0
        cps_passed = cars_passed / simulation_duration

        # Graph of average wait time and cars passed through the intersection *MAYBE*
    print(f"Simulation complete. Average wait time: {avg_wait_time:.2f}s Cars per second passed: {cps_passed:.2f}")

    # Graph of average wait time and cars passed through the intersection
    timing_variables = [lightDuration, car_probabilities, busProb, truckProb, leftTurn]
    labels = ["Light Duration", "Car Probability", "Bus Probability", "Truck Probability", "Left Turn Probability"]
    fig, ax = plt.subplots(2, 1, figsize=(10, 8))
    ax[0].plot(timing_variables, totalCars, marker='o')
    ax[0].set_xlabel("Timing Variables")
    ax[0].set_ylabel("Number of Cars")
    ax[1].plot(timing_variables, avg_wait_time, marker='o')
    ax[1].set_xlabel("Timing Variables")
    ax[1].set_ylabel("Average Wait Time (seconds)")
    ax[0].set_xticks(range(len(timing_variables)))
    ax[0].set_xticklabels(labels, rotation=45)
    ax[0].set_yticks(range(len(timing_variables)))
    ax[0].set_yticklabels(labels, rotation=45)


# Run the simulation
simulate_traffic_light(10, 0.3, 30, 0.2, 0.1, 0.1)


def main(generateVehicles=None, initialize=None, signalCoods=None, noOfSignals=None, currentGreen=None,
         currentYellow=None, signalTimerCoods=None, simulation=None):
    thread1 = threading.Thread(name="initialization", target=initialize, args=())  # initialization
    thread1.daemon = True
    thread1.start()

    # Colours 
    black = (0, 0, 0)
    white = (255, 255, 255)

    # Screensize 
    screenWidth = 1400
    screenHeight = 800
    screenSize = (screenWidth, screenHeight)

    # Setting background image i.e. image of intersection
    background = pygame.image.load('images/intersection.png')

    screen = pygame.display.set_mode(screenSize)
    pygame.display.set_caption("SIMULATION")

    # Loading signal images and font
    redSignal = pygame.image.load('images/signals/red.png')
    yellowSignal = pygame.image.load('images/signals/yellow.png')
    greenSignal = pygame.image.load('images/signals/green.png')
    font = pygame.font.Font(None, 30)

    thread2 = threading.Thread(name="generateVehicles", target=generateVehicles, args=())  # Generating vehicles
    thread2.daemon = True
    thread2.start()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()

        screen.blit(background, (0, 0))  # display background in simulation
        for i in range(0,
                       noOfSignals):  # display signal and set timer according to current status: green, yello, or red
            if (i == currentGreen):
                if (currentYellow == 1):
                    signals[i].signalText = signals[i].yellow
                    screen.blit(yellowSignal, signalCoods[i])
                else:
                    signals[i].signalText = signals[i].green
                    screen.blit(greenSignal, signalCoods[i])
            else:
                if (signals[i].red <= 10):
                    signals[i].signalText = signals[i].red
                else:
                    signals[i].signalText = "---"
                screen.blit(redSignal, signalCoods[i])
        signalTexts = ["", "", "", ""]

        # display signal timer
        for i in range(0, noOfSignals):
            signalTexts[i] = font.render(str(signals[i].signalText), True, white, black)
            screen.blit(signalTexts[i], signalTimerCoods[i])

        # display the vehicles
        for vehicle in simulation:
            screen.blit(vehicle.image, [vehicle.x, vehicle.y])
            vehicle.move()
        pygame.display.update()

    screen.blit(background, (0, 0))  # display background in simulation
    for i in range(0, noOfSignals):  # display signal and set timer according to current status: green, yello, or red
        if (i == currentGreen):
            if (currentYellow == 1):
                signals[i].signalText = signals[i].yellow
                screen.blit(yellowSignal, signalCoods[i])
            else:
                signals[i].signalText = signals[i].green
                screen.blit(greenSignal, signalCoods[i])
        else:
            if (signals[i].red <= 10):
                signals[i].signalText = signals[i].red
            else:
                signals[i].signalText = "---"
            screen.blit(redSignal, signalCoods[i])
    signalTexts = ["", "", "", ""]
