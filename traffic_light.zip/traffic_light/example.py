import pygame
import sys
import time
import random
import matplotlib.pyplot as plt

# Define colors
BLACK = (0, 0, 0)
WHITE = (255, 255,255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Define window dimensions
WIDTH, HEIGHT = 600, 600
# Define car dimensions
CAR_WIDTH, CAR_HEIGHT = 30,20
# Define traffic light dimensions
LIGHT_WIDTH, LIGHT_HEIGHT = 30, 90
MARGIN = 20

# Initialize Pygame
pygame.init()

# Create window
window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Traffic Light Simulation -- Car Intersection")

# Function to draw the traffic light
def draw_traffic_light(light1, light2):
    pygame.draw.rect(window, BLACK, (WIDTH // 2 - LIGHT_WIDTH // 2, MARGIN, LIGHT_WIDTH, LIGHT_HEIGHT))
    pygame.draw.circle(window, light1, (WIDTH // 2, MARGIN + LIGHT_HEIGHT // 4), 15)

    pygame.draw.rect(window, BLACK, (WIDTH // 2 - LIGHT_WIDTH // 2, HEIGHT - MARGIN - LIGHT_HEIGHT, LIGHT_WIDTH, LIGHT_HEIGHT))
    pygame.draw.circle(window, light2, (WIDTH // 2, HEIGHT - MARGIN - 3 * LIGHT_HEIGHT // 4), 15)

# Function to draw the vehicle
def draw_vehicle(x, y, vehicle_type):
    color = WHITE
    if vehicle_type == 'bus':
        color = (0, 0, 255)  # Blue for buses
    elif vehicle_type == "car":
        color = (255,0,255)
    elif vehicle_type == 'truck':
        color = (255, 255, 0)  # Yellow for trucks
    pygame.draw.rect(window, color, (x, y, CAR_WIDTH, CAR_HEIGHT))

# Main simulation loop
def simulate_traffic_light(light_duration, car_probability, simulation_duration,
                            bus_probability=None, truck_probability=None, left_turn_probability=None):
    # Initialize variables
    light1 = GREEN
    light2 = RED
    total_wait_time = 0
    total_cars = 0
    cars_passed = 0
    clock = pygame.time.Clock()

    # Vehicle parameters
    vehicle_types = ['car', 'bus', 'truck']
    vehicle_probs = {'car': car_probability, 'bus': bus_probability, 'truck': truck_probability}
    vehicle_times = {'car': 3, 'bus': 5, 'truck': 7}

    time = 0
    while time < simulation_duration:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        # Update traffic light colors
        draw_traffic_light(light1, light2)

        # Simulate vehicles arriving at the intersection
        for vehicle_type in vehicle_types:
            if random.random() <= vehicle_probs[vehicle_type]:
                # Check if the vehicle can proceed (no left turn)
                if random.random() > left_turn_probability:
                    total_cars += 1
                    total_wait_time += vehicle_times[vehicle_type]
                    # Draw the vehicle
        draw_vehicle(WIDTH // 2 - CAR_WIDTH // 2, HEIGHT - MARGIN - CAR_HEIGHT, vehicle_type)

        # Print statistics
        print(f"Time: {time}s State: {light1,light2} Total Cars Passed: {cars_passed} Total Wait Time: {total_wait_time:.2f}s")

        pygame.display.flip()
        clock.tick(1)  # Update every second

        # Change traffic light colors
        if light1 == GREEN:
            light1 = RED
            light2 = GREEN
        else:
            light1 = GREEN
            light2 = RED

        window.fill(BLACK)

    # Calculate average wait time and cars per second passed
    avg_wait_time = total_wait_time / cars_passed
    cps_passed = cars_passed / simulation_duration

    print(f"Simulation complete. Average wait time: {avg_wait_time:.2f}s Cars per second passed: {cps_passed:.2f}")

    # Graph of average wait time and cars passed through the intersection
    timing_variables = [light_duration, car_probability, bus_probability, truck_probability, left_turn_probability]
    labels = ["Light Duration", "Car Probability", "Bus Probability", "Truck Probability", "Left Turn Probability"]
    fig, ax = plt.subplots(2, 1, figsize=(10, 8))
    ax[0].plot(timing_variables, total_cars, marker='o')
    ax[0].set_xlabel("Timing Variables")
    ax[0].set_ylabel("Number of Cars")
    ax[1].plot(timing_variables, avg_wait_time, marker='o')
    ax[1].set_xlabel("Timing Variables")
    ax[1].set_ylabel("Average Wait Time (seconds)")
    ax[0].set_xticks(range(len(timing_variables)))
    ax[0].set_xticklabels(labels, rotation=45)
    ax[0].set_yticks(range(len(timing_variables)))
    ax[0].set_yticklabels(labels, rotation=45)

# Run the simulation
simulate_traffic_light(10, 0.3, 30, 0.2, 0.1, 0.1)


